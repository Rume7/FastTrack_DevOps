# 👋 Hello World Classroom Project

Welcome to the **Hello World Project** for GitHub beginners!

This project will help you learn how to:
- Fork a repository
- Clone it to your computer
- Create and commit a file
- Push it to GitHub
- Open a Pull Request (PR)

---

## 📝 Instructions

1. **Fork** this repository to your GitHub account.
2. **Clone** your fork using this command:
   ```bash
   git clone https://github.com/<your-username>/hello-world-classroom.git
   ```
3. **Navigate** to the `submissions/` folder and create a new file named `<your-name>.txt`. You can use this command:
   ```bash
   echo "Hi, I'm learning GitHub!" > submissions/<your-name>.txt
   ```
4. **Add and Commit** your file:
   ```bash
   git add submissions/<your-name>.txt
   git commit -m "Add hello world message from <your-name>"
   ```
5. **Push** your changes to your GitHub fork:
   ```bash
   git push origin main
   ```
6. **Open a Pull Request** to the original repository.

---

Happy coding! 🎉